﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SinglePlyCutter
{
    static class Global
    {

        public const String appName = "Application Name V1.0";

        public const String aboutText = "About " + appName;

    }
}
