﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Reflection;
using KMotion_dotNet;
using System.Timers;

namespace SinglePlyCutter
{

    sealed class Controller
    {
        private static readonly object lck = new object();
        private static Controller instance = null;
        public static bool ExecutionInProgress = false;
        static KMotion_dotNet.KM_Controller KM;
        static bool Connected = false;
        static int skip = 0;
        static string MainPath;
        public static KM_MainStatus MainStatus;
        private readonly string CFileInitAxes = @"C:\Users\ertan\Desktop\conini.c";
        private readonly string CFileInitKonnect = @"C:\Users\ertan\Desktop\konnectini.c";
        System.Timers.Timer timer;
        public bool stopState { get; set; }
        private string gcodeFile;
        public string GCodeFile
        {

            get
            {
                return gcodeFile;
            }

            set
            {
                gcodeFile = value;
            }
        }


        public struct ActualPositions
        {

            public double x;
            public double y;
            public double z;
            public double a;
        }

        public ActualPositions actualPositions;





        Controller() { }

        public static Controller getInstance()
        {
            {

                lock (lck)
                {
                    if (instance == null)
                    {
                        instance = new Controller();

                    }

                    return instance;

                }
            }

        }




        public void InitializeController(MainWindow w)


        {


            //Create an instance of the KM the same instance should be used throughout the app
            try
            {
                KM = new KMotion_dotNet.KM_Controller();
            }
            catch (Exception e)
            {
                MessageBox.Show("Unable to load KMotion_dotNet Libraries.  Check Windows PATH or .exe location\r\r" + e.Message);
                System.Windows.Application.Current.Shutdown();
                return;
            }
            //Add all various callbacks
            AddHandlers();

            //Load a C program, first figure out what directory we are installed into
            string codeBase = Assembly.GetExecutingAssembly().CodeBase;
            UriBuilder uri = new UriBuilder(codeBase);
            MainPath = Uri.UnescapeDataString(uri.Path);
            MainPath = System.IO.Path.GetDirectoryName(MainPath);
            MainPath = System.IO.Path.GetDirectoryName(MainPath);
            MainPath = System.IO.Path.GetDirectoryName(MainPath);




            //Execute it
            try
            {
                KM.ExecuteProgram(1, CFileInitAxes, false);
                KM.ExecuteProgram(2, CFileInitKonnect, false);
            }
            catch (DMException e)
            {
                MessageBox.Show("Unable to Execute C Program in KFLOP\r\r" + e.InnerException.Message);
            }

            // default a simple GCode File
            w.GCodeFile.Text = @"C:\KMotion434\GCode Programs\box.ngc";

            // Start a Timer for status updates
            timer = new System.Timers.Timer(100);
            timer.Elapsed += new System.Timers.ElapsedEventHandler(Timer_Elapsed);
            timer.Start();


            SetMotionParameters(); // Set some motion Parameters


        }
        int abc = 100;

        // update status
        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {

            int[] List;
            int nBoards = 0;

            // with extra FTDI Drivers this can take a long time
            // so only call occasionally when not connected
            if (!Connected && ++skip == 10)
            {
                skip = 0;

                // check how many boards connected
                List = KM.GetBoards(out nBoards);
                if (nBoards > 0)
                {
                    Connected = true;
                }
                else
                {
                    Connected = false;
                }
            }




            if (Connected && KM.WaitToken(100) == KMOTION_TOKEN.KMOTION_LOCKED)
            {
                try
                {
                    MainStatus = KM.GetStatus(false);  // we already have a lock
                    KM.ReleaseToken();



                    // Get Absolute Machine Coordinates and display in DROs
                    double x = 0, y = 0, z = 0, a = 0, b = 0, c = 0;
                    KM.CoordMotion.UpdateCurrentPositionsABS(ref x, ref y, ref z, ref a, ref b, ref c, false); // The returned values are inches.


                    actualPositions.x = KM.CoordMotion.Interpreter.InchesToUserUnits(x); // to mm
                    actualPositions.y = KM.CoordMotion.Interpreter.InchesToUserUnits(y);
                    actualPositions.z = KM.CoordMotion.Interpreter.InchesToUserUnits(z);
                    actualPositions.a = KM.CoordMotion.Interpreter.InchesToUserUnits(a);



                    // Set Feedhold color bases on state
                    if (KM.WriteLineReadLine("GetStopState") == "0")
                        stopState = false;
                    else
                        stopState = true;






                }
                catch (DMException) // in case disconnect in the middle of reading status
                {
                    KM.ReleaseToken();  // make sure token is released
                }
            }
            else
            {
                Connected = false;
            }


        }





        // Cycle Start
        public void Run()
        {


            if (ExecutionInProgress) return;  // ignore if we are already executing
            ExecutionInProgress = true;
            KM.CoordMotion.Abort();
            KM.CoordMotion.ClearAbort();

            KM.CoordMotion.Interpreter.InitializeInterpreter();

            //Set_Fixture_Offset(2, 2, 3, 0);  // set XYZ offsets for G55

            KM.CoordMotion.Interpreter.Interpret(GCodeFile);  // Execute the File!
        }

        private void Set_Fixture_Offset(int Fixture_Number, double X, double Y, double Z)
        {
            // Set GVars for Offsets
            KM.CoordMotion.Interpreter.SetOrigin(Fixture_Number,
                KM.CoordMotion.Interpreter.InchesToUserUnits(X),
                KM.CoordMotion.Interpreter.InchesToUserUnits(Y),
                KM.CoordMotion.Interpreter.InchesToUserUnits(Z), 0, 0, 0);

            KM.CoordMotion.Interpreter.SetupParams.OriginIndex = -1;  // force update from GCode Vars
            KM.CoordMotion.Interpreter.ChangeFixtureNumber(Fixture_Number);  // Load offsets for fixture
        }

        public void Feedhold()
        {

            try
            {
                if (KM.WriteLineReadLine("GetStopState") == "0")
                    KM.Feedhold();
                else
                    KM.ResumeFeedhold();
            }
            catch (Exception)
            {
                KM.ReleaseToken();
            }
        }

        public void Halt()
        {

            KM.CoordMotion.Interpreter.Halt();
        }

        /// <summary>
        /// Handler for the error message pump
        /// </summary>
        /// <param name="message">error string</param>
        static void KM_ErrorUpdated(string message)
        {
            MessageBox.Show(message);
        }

        static void Interpreter_InterpreterCompleted(int status, int lineno, int sequence_number, string err)
        {
            if (status != 0 && status != 1005) MessageBox.Show(err);  //status 1005 = successful halt
            ExecutionInProgress = false;
        }

        private void AddHandlers()
        {
            //Set the callback for Errors
            KM.ErrorReceived += new KMotion_dotNet.KMErrorHandler(KM_ErrorUpdated);

            //Set the Interpreter's callbacks
            KM.CoordMotion.Interpreter.InterpreterCompleted += new KMotion_dotNet.KM_Interpreter.KM_GCodeInterpreterCompleteHandler(Interpreter_InterpreterCompleted);
        }

        // configure motion parameters
        private void SetMotionParameters()
        {
            KM.CoordMotion.MotionParams.BreakAngle = 30;
            KM.CoordMotion.MotionParams.MaxAccelX = 80;
            KM.CoordMotion.MotionParams.MaxAccelY = 80;
            KM.CoordMotion.MotionParams.MaxAccelZ = 80;
            KM.CoordMotion.MotionParams.MaxAccelA = 120;
            KM.CoordMotion.MotionParams.MaxAccelB = 80;
            KM.CoordMotion.MotionParams.MaxAccelC = 80;
            KM.CoordMotion.MotionParams.MaxVelX = 800;
            KM.CoordMotion.MotionParams.MaxVelY = 800;
            KM.CoordMotion.MotionParams.MaxVelZ = 800;
            KM.CoordMotion.MotionParams.MaxVelA = 800;
            KM.CoordMotion.MotionParams.MaxVelB = 800;
            KM.CoordMotion.MotionParams.MaxVelC = 800;
            KM.CoordMotion.MotionParams.CountsPerInchX = 500;
            KM.CoordMotion.MotionParams.CountsPerInchY = 500;
            KM.CoordMotion.MotionParams.CountsPerInchZ = 500;
            KM.CoordMotion.MotionParams.CountsPerInchA = 500;
            KM.CoordMotion.MotionParams.CountsPerInchB = 500;
            KM.CoordMotion.MotionParams.CountsPerInchC = 500;
            KM.CoordMotion.MotionParams.DegreesA = false;
            KM.CoordMotion.MotionParams.DegreesB = false;
            KM.CoordMotion.MotionParams.DegreesC = false;


            KM.CoordMotion.MotionParams.TPLookahead = 40;

            KM.CoordMotion.MotionParams.CollinearTolerance = 0.04; // inch

            KM.CoordMotion.MotionParams.CornerTolerance = 0.04;

            KM.CoordMotion.MotionParams.FacetAngle = 1;

            KM.CoordMotion.MotionParams.ArcsToSegs = true;


            KM.CoordMotion.MotionParams.SetTPParams();

            KM.CoordMotion.Interpreter.SetupParams.LengthUnits = CANON_UNITS.CANON_UNITS_MM;


            KM.CoordMotion.Interpreter.SetupParams.ControlMode = CANON_MOTION_MODE.CANON_CONTINUOUS;
        }
        public void Dispose()
        {

            timer.Stop();
            KM.Dispose();

        }
    }
}
