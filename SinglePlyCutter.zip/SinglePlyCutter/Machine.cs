﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace SinglePlyCutter
{
    sealed class Machine
    {

        private static readonly object lck = new object();
        private static Machine instance = null;


        Machine() { }

        public static Machine getInstance(MainWindow w)
        {
            {

                lock (lck)
                {
                    if (instance == null)
                    {
                        instance = new Machine();
                        Controller.getInstance().InitializeController(w);

                    }

                    return instance;

                }
            }

        }


    }
}
