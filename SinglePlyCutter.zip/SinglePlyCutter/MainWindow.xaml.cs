﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SinglePlyCutter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Ellipse ellipse = new Ellipse();

        private double scaleValue = 1;

        public MainWindow()
        {
            InitializeComponent();
            Machine.getInstance(this);
            Controller.getInstance().GCodeFile = GCodeFile.Text;


            System.Timers.Timer uiTimer = new System.Timers.Timer(100);
            uiTimer.Elapsed += new System.Timers.ElapsedEventHandler(UiTimer_Elapsed);
            uiTimer.Start();



            ellipse.Fill = Brushes.Red;
            ellipse.Width = 20;
            ellipse.Height = 20;
            ellipse.Stroke = System.Windows.Media.Brushes.LightSteelBlue;
            ellipse.StrokeThickness = 1;

            canvas.Children.Add(ellipse);


        }

        private void UiTimer_Elapsed(object sender, ElapsedEventArgs e)
        {



            DROX.Dispatcher.Invoke(() =>
            {
                DROX.Text = String.Format("{0:F4}", Controller.getInstance().actualPositions.x);

                if ((Controller.MainStatus.Enables & 1) != 0)  // Set DRO colors based on enables
                    DROX.Foreground = Brushes.Green;
                else
                    DROX.Foreground = Brushes.Orange;
            });
            DROY.Dispatcher.Invoke(() =>
            {
                DROY.Text = String.Format("{0:F4}", Controller.getInstance().actualPositions.y);

                if ((Controller.MainStatus.Enables & 2) != 0)
                    DROY.Foreground = Brushes.Green;
                else
                    DROY.Foreground = Brushes.Orange;
            });

            DROZ.Dispatcher.Invoke(() =>
            {
                DROZ.Text = String.Format("{0:F4}", Controller.getInstance().actualPositions.z);

                if ((Controller.MainStatus.Enables & 4) != 0)
                    DROZ.Foreground = Brushes.Green;
                else
                    DROZ.Foreground = Brushes.Orange;
            });
            DROA.Dispatcher.Invoke(() =>
            {
                DROA.Text = String.Format("{0:F4}", Controller.getInstance().actualPositions.a);

                if ((Controller.MainStatus.Enables & 8) != 0)
                    DROA.Foreground = Brushes.Green;
                else
                    DROA.Foreground = Brushes.Orange;
            });



            Feedhold.Dispatcher.Invoke(() =>
            {
                // Set Feedhold color bases on state
                if (Controller.getInstance().stopState)
                    Feedhold.Background = Brushes.Red;
                else
                    Feedhold.Background = Brushes.White;
            });


            Run.Dispatcher.Invoke(() =>
            {
                // update Run button color/enable
                Run.IsEnabled = !Controller.ExecutionInProgress;
            });



            ellipse.Dispatcher.Invoke(() => {
            ellipse.Margin= new Thickness(Controller.getInstance().actualPositions.x/scaleValue - 10, Controller.getInstance().actualPositions.y/scaleValue - 10, 0, 0);
            });


        }

        public void Feedhold_Click(object sender, RoutedEventArgs e)
        {


            Controller.getInstance().Feedhold();
        }

        public void Halt_Click(object sender, RoutedEventArgs e)
        {
            Controller.getInstance().Halt();
        }

        public void Run_Click(object sender, RoutedEventArgs e)
        {


            Controller.getInstance().Run();
        }


        public void Simulation_Click(object sender, RoutedEventArgs e) {




            canvas.Dispatcher.Invoke(() => {

            canvas.Children.Clear();
                canvas.Children.Add(ellipse);



            List<Point> points  = getXYpointsFromGFile(GCodeFile.Text);

            Point last = new Point();
            for (int i = 0; i < points.Count - 1 ; i++)
            {
                Line line = new Line();
                line.Stroke = System.Windows.Media.Brushes.LightSteelBlue;
                line.StrokeThickness = 1;
                last = points[i];
                line.X1 = last.X;
                line.Y1 = last.Y;

                line.X2 = points[i + 1].X;
                line.Y2 = points[i + 1].Y;


                    canvas.Children.Add(line);



            }

            });



        }
        public void BrowseGCode_Click(object sender, RoutedEventArgs e)
        {
            // Create OpenFileDialog
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

            // Set filter for file extension and default file extension
            dlg.DefaultExt = ".ngc";
            dlg.Filter = "ngc Files (*.ngc)|*.ngc|txt Files (*.txt)|*.txt";

            // Show Dialog and get the selected file name and display in a TextBox
            if (dlg.ShowDialog() == true) GCodeFile.Text = dlg.FileName;
            Controller.getInstance().GCodeFile = GCodeFile.Text;


        }


        private void Window_Closed(object sender, EventArgs e)
        {
            Controller.getInstance().Dispose();
        }




        private List<Point> getXYpointsFromGFile(String file) {


            String text = File.ReadAllText(file);
            String[] gcodes = text.Split(new String[] { "\n", "\r" }, StringSplitOptions.None);
            List<Point> points = new List<Point>();



            foreach (String gcode in gcodes)
            {

                Console.WriteLine(gcode);

                if (gcode.StartsWith("G01") || gcode.StartsWith("G1"))
                {

                    String s = gcode.StartsWith("G01") ? gcode.Substring(4) : gcode.Substring(3);

                    if (s.StartsWith("X"))
                    {

                        String[] parts = s.Split(' ');

                        float x = float.Parse(parts[0].Substring(1));

                        float y = float.Parse(parts[1].Substring(1));

                        points.Add(new Point(x/scaleValue, y/scaleValue));


                    }

                }

            }
            return points;




        }



    }
}
